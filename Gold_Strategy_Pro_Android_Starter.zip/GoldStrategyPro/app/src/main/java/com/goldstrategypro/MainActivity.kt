package com.goldstrategypro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D32)
private val Gold = Color(0xFFE5B84B)
private val Muted = Color(0xFF9AA7BD)
private val Green = Color(0xFF38C98B)
private val Red = Color(0xFFFF6878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldApp() }
    }
}

@Composable
fun GoldApp() {
    var tab by remember { mutableStateOf("Overview") }
    var risk by remember { mutableFloatStateOf(1f) }
    var capital by remember { mutableStateOf("10000") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Gold,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Text("GOLD STRATEGY PRO", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Delta Exchange India • Strategy dashboard", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Overview", "Signals", "Tools").forEach { item ->
                    FilterChip(selected = tab == item, onClick = { tab = item }, label = { Text(item) })
                }
            }
            Spacer(Modifier.height(12.dp))
            when (tab) {
                "Overview" -> Overview(risk, { risk = it }, capital, { capital = it })
                "Signals" -> Signals()
                else -> Tools()
            }
            Spacer(Modifier.weight(1f))
            Text("DEMO UI • Not connected to live market data • No trade execution",
                color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun PanelCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), content = {
            Text(title, color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            content()
        })
    }
}

@Composable
fun Overview(risk: Float, onRisk: (Float) -> Unit, capital: String, onCapital: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            PanelCard("MARKET STATUS") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Gold market", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Live feed not connected", color = Muted, fontSize = 11.sp) }
                    Text("WAIT", color = Gold, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(6.dp))
                Text("No verified entry signal. Connect a supported market-data feed before using signals.",
                    color = Muted, fontSize = 12.sp)
            }
        }
        item {
            PanelCard("RISK MANAGEMENT") {
                OutlinedTextField(value = capital, onValueChange = onCapital,
                    label = { Text("Trading capital (INR)") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Text("Risk per trade: ${"%.1f".format(risk)}%", color = Color.White)
                Slider(value = risk, onValueChange = onRisk, valueRange = 0.25f..2f)
                val amount = (capital.toDoubleOrNull() ?: 0.0) * risk / 100.0
                Text("Planned maximum risk: ₹${"%.2f".format(amount)}", color = Gold, fontWeight = FontWeight.Bold)
                Text("Position size still requires entry price, stop distance, contract size and fees.",
                    color = Muted, fontSize = 11.sp)
            }
        }
        item {
            PanelCard("STRATEGY MODULES") {
                listOf("ICT / SMC • BOS / CHoCH", "Liquidity sweep • Equal highs/lows",
                    "Order blocks • FVG / IFVG", "Support / Resistance • Supply / Demand",
                    "Candlestick patterns • Fibonacci", "Trend reversal • Fake breakout filter",
                    "Footprint • Bid/Ask • Delta • CVD", "News calendar • FOMC / CPI / NFP",
                    "Options Greeks • Delta / Gamma / Theta / Vega").forEach {
                    Text("✓  $it", color = Color.White, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
fun Signals() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PanelCard("SIGNAL ENGINE") {
            Text("Strong-signal mode selected", color = Gold, fontWeight = FontWeight.Bold)
            Text("The engine is not yet calculating live signals. It needs verified candles, volume and order-flow data.",
                color = Muted, fontSize = 12.sp)
        } }
        item { PanelCard("BUY / SELL CHECKLIST") {
            listOf("Higher-timeframe trend alignment", "Liquidity sweep confirmation",
                "BOS / CHoCH structure break", "FVG / order-block retest",
                "Footprint delta / absorption confirmation", "Volume and volatility filter",
                "High-impact news blackout").forEach { Text("○  $it", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(5.dp)) }
        } }
        item { PanelCard("SIGNAL STATUS") {
            Text("NO TRADE", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Demo status only; not a market recommendation.", color = Muted, fontSize = 11.sp)
        } }
    }
}

@Composable
fun Tools() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { PanelCard("FOOTPRINT / ORDER FLOW") {
            Text("Planned: Bid × Ask, volume delta, stacked imbalance, absorption, exhaustion, POC and CVD.",
                color = Color.White, fontSize = 12.sp)
            Text("True footprint requires exchange trade-level data and aggressor-side classification.",
                color = Muted, fontSize = 11.sp)
        } }
        item { PanelCard("OPTIONS GREEKS") {
            Text("Delta • Gamma • Theta • Vega • Rho", color = Color.White)
            Text("Greeks are only meaningful when valid Gold options contract and implied-volatility data are available.",
                color = Muted, fontSize = 11.sp)
        } }
        item { PanelCard("NEWS FILTER") {
            Text("FOMC / Fed • CPI • PCE • NFP • DXY • Treasury yields • geopolitical headlines",
                color = Color.White, fontSize = 12.sp)
            Text("Calendar and headlines are placeholders until a licensed/current news source is connected.",
                color = Muted, fontSize = 11.sp)
        } }
        item { PanelCard("DATA CONNECTION") {
            Text("Exchange: Delta Exchange India", color = Color.White)
            Text("API keys must never be hard-coded in the app. Use a secure backend and read-only permissions for market data.",
                color = Muted, fontSize = 11.sp)
        } }
    }
}
