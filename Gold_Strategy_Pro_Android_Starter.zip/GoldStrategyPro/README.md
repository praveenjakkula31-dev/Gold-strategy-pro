# Gold Strategy Pro — Android starter project

This is a free, native Android Studio starter project for the requested Gold Strategy Pro dashboard.

## Included in this demo
- Overview, Signals and Tools screens
- 1% default risk control and capital-risk amount calculator
- Strategy module checklist: ICT/SMC, BOS/CHoCH, liquidity sweeps, order blocks, FVG/IFVG, S/R, supply/demand, candlesticks and Fibonacci
- Footprint/order-flow module checklist
- News filter checklist: FOMC, CPI, PCE, NFP, DXY, yields and geopolitical news
- Options Greeks module checklist: Delta, Gamma, Theta, Vega and Rho
- Clear demo/no-live-data status; no fake live prices or signals

## Important limitations
This project is a UI starter, **not a finished trading system**. It does not yet connect to Delta Exchange, fetch live candles, calculate live footprint/order flow, retrieve a news calendar, calculate option Greeks from a live options chain, or place orders. The app deliberately shows NO TRADE rather than inventing a signal.

True footprint requires trade-level data with aggressor-side classification. Greeks require a real options contract chain and implied volatility. A gold futures/spot instrument does not itself have option Greeks.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync; install Android SDK 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

## Before live use
- Verify the exact Delta Exchange India gold instrument and supported market-data endpoints.
- Implement a secure backend for exchange data; do not embed API secrets in the APK.
- Add licensed economic-calendar/news data.
- Validate indicator calculations against historical data and paper-trade before considering live use.
- Add tests, reconnect handling, timestamp/timezone handling, fees, slippage and risk limits.

This starter does not provide financial advice and does not execute trades.
